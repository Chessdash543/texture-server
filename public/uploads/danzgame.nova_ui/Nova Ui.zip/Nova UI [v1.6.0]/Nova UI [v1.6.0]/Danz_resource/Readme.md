Author: DANZGAME
Name: Nova Ui
Version: v1.6.0

NOVA UI is a name derived from the word innovation, which means developing ideas in a field.

Features In Nova Ui:
1. Change The Main Menu View
2. Change Creator Layer View
3. Shader Menu In Main Menu
4. Animated Background
5. Ui Animation

Must Download Mods:
1. Texture Loader
2. Menu Shader
3. Happy Texture
4. Animate This Sprite

Note: if you download many mods at the bottom then the main menu will have a bug

Changelog:
v1.0.0 : 2/5/2025
Ui released and uploaded to Texture workshop

v1.1.0 : 10/5/2025
Fixed bug in layer creator on pc
Fixed bug in main menu on pc
Adding animated background

v1.2.0 : 7/6/2025
Ui Improvements
Change Animation Background
Adding Ui Animation
Adding Quest Button In Pause Layer

v1.3.0 : 24/7/2025
Update Ui Animation Speed
Remove Quest Button
Added Hover Animation
Added Ui Animation In Editor

v1.4.0 : 16/8/2025
Update Ui Improvement
Added Background Player
Added Changelog
Remove Button Actions On Mobile

v1.5.0 : 20/9/2025
Added Hide Ui
Added Orb Info In Paths
Added Support
Change Loading Layer View
Update Info Button
Fixed Background Player

v1.6.0 : 6/11/2025
Added Badge In Credits Info
Added Level Password
Added Ui Animation In Icons Layer
Change Texture Pack Icon
Update Loading Layer
Update Info Menu

Special Thanks To BoomyBoomer123 For Helping Me Find The Error In The Ui

Credits:
Background: https://youtu.be/ag13IgTauU8?si=GD0j-WlXVyF5k6u8
Main Menu Background: https://youtu.be/SU0CCJbHYYk?si=2a4lg0lXco8zwDEC
Loading Background: https://www.baltana.com/backgrounds/background-design-wallpaper-hd-16247.html
Song: https://youtu.be/3u43yUcB8uY?si=O5Z8WZQm6AuM4odI